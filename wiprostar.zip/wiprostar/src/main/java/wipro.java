
import java.io.IOException;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/wipro")
public class wipro extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");  
		PrintWriter out = response.getWriter();  	         
		String n=request.getParameter("userN");  
		String p=request.getParameter("userF");  
		String e=request.getParameter("userD");  
		String c=request.getParameter("userG");  
		String a=request.getParameter("userPA");  
		String b=request.getParameter("userAD");  
		String d=request.getParameter("userP");  
		String f=request.getParameter("userL"); 
		String g=request.getParameter("userM");  
		String h=request.getParameter("userC");  
		String i=request.getParameter("userA");  
		String j=request.getParameter("userBA");  
		String k=request.getParameter("userB"); 		          
		try{
		Class.forName("oracle.jdbc.driver.OracleDriver");  
		Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","dhaya","1234");  
		out.print(conn);
		PreparedStatement ps=conn.prepareStatement("insert into atm values(?,?,?,?,?,?,?,?,?,?,?,?,?)");  	  
		ps.setString(1,n);  
		ps.setString(2,p);  
		ps.setString(3,e);  
		ps.setString(4,c);  
		ps.setString(5,a);  
		ps.setString(6,b);  
		ps.setString(7,d);  
		ps.setString(8,f); 
		ps.setString(9,g);  
		ps.setString(10,h);  
		ps.setString(11,i);  
		ps.setString(12,j);  
		ps.setString(13,k);	          
		ps.executeUpdate();  
		response.sendRedirect("login.jsp"); 		
		out.flush();
		out.close(); 	
		}catch(Exception e2) {
			out.print(e2);
		}		
	}  
}